from PyQt6 import QtWidgets as qt
from PyQt6 import QtCore as qt2
from yt_dlp import YoutubeDL
class YoutubeObjects(qt2.QObject):
    progress=qt2.pyqtSignal(int)
    finished=qt2.pyqtSignal(bool)
class YoutubeThread(qt2.QRunnable):
    def __init__(self, url, path):
        super().__init__()
        self.objects=YoutubeObjects()
        self.url=url
        self.path=path
    def run(self):
        try:
            ydl_opts={
                'format': 'bestaudio/best',
                'outtmpl': f'{self.path}/%(title)s.%(ext)s',
                'progress_hooks': [self.progress_hook],
                'quiet': True,
            }
            with YoutubeDL(ydl_opts) as ydl:
                ydl.download([self.url])
            self.objects.finished.emit(True)
        except Exception as e:
            print(e)
            self.objects.finished.emit(False)
    def progress_hook(self, d):
        if d['status'] == 'downloading':
            total_bytes=d.get('total_bytes', 0)
            downloaded_bytes=d.get('downloaded_bytes', 0)
            if total_bytes > 0:
                progress_percentage=int((downloaded_bytes / total_bytes) * 100)
                self.objects.progress.emit(progress_percentage)
class HighQualityAudioDownloadDialog(qt.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تنزيل كصوت بأعلى جودة")
        self.thread_pool=qt2.QThreadPool(self)
        self.حفظ=qt.QPushButton("تحديد مكان الحفظ أولاً (O)")
        self.حفظ.setShortcut("o")
        self.حفظ.setDefault(True)
        self.حفظ.clicked.connect(self.openFile)
        self.إظهار1=qt.QLabel("مسار الحفظ")
        self.التعديل=qt.QLineEdit()
        self.التعديل.setReadOnly(True)
        self.التعديل.setAccessibleName("مسار الحفظ")
        self.إظهار3=qt.QLabel("إدخال الرابط هنا")
        self.الرابط=qt.QLineEdit()
        self.الرابط.setAccessibleName("إدخال الرابط هنا")
        self.التحميل=qt.QPushButton("بدء التحميل (D)")
        self.التحميل.setDefault(True)
        self.التحميل.setShortcut("d")
        self.التحميل.clicked.connect(self.dl)
        self.progress_bar=qt.QProgressBar()
        self.progress_bar.setValue(0)
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.حفظ)
        layout.addWidget(self.إظهار1)
        layout.addWidget(self.التعديل)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.إظهار3)
        layout.addWidget(self.الرابط)
        layout.addWidget(self.التحميل)
    def openFile(self):
        directory=qt.QFileDialog.getExistingDirectory(self, "اختر مكان الحفظ")
        if directory:
            self.التعديل.setText(directory)
    def dl(self):
        if not self.الرابط.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء إدخال رابط الفيديو")
            return
        if not self.التعديل.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء تحديد مكان الحفظ")
            return
        qt.QMessageBox.information(self, "تنبيه", "لقد بدأ التحميل الآن، الرجاء الانتظار حتى يتم التحميل")
        self.التحميل.setDisabled(True)
        thread=YoutubeThread(self.الرابط.text(), self.التعديل.text())
        thread.objects.progress.connect(self.update_progress)
        thread.objects.finished.connect(self.onFinish)
        self.thread_pool.start(thread)
    def update_progress(self, value):
        self.progress_bar.setValue(value)
    def onFinish(self, state):
        if state:
            qt.QMessageBox.information(self, "تم", "تم التحميل بنجاح والحفظ")
        else:
            qt.QMessageBox.critical(self, "تنبيه", "فشلت عملية التحميل، ربما تكون المشكلة من الرابط أو الإنترنت")
        self.التحميل.setDisabled(False)
        self.progress_bar.setValue(0)