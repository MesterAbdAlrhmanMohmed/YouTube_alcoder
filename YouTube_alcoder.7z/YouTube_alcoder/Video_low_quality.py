from PyQt6 import QtWidgets as qt
from PyQt6 import QtCore as qt2
from yt_dlp import YoutubeDL
class YoutubeObjects(qt2.QObject):
    Finish=qt2.pyqtSignal(bool)
    progress=qt2.pyqtSignal(int)
class YoutubeThread(qt2.QRunnable):
    def __init__(self, url, path, progress_bar):
        super().__init__()
        self.objects=YoutubeObjects()
        self.url=url
        self.path=path
        self.progress_bar=progress_bar
    def run(self):
        try:
            ydl_opts={
                'format': 'worst',
                'outtmpl': f"{self.path}/%(title)s.%(ext)s",
                'noplaylist': True,
                'progress_hooks': [self.progress_hook],
                'quiet': False,
            }
            with YoutubeDL(ydl_opts) as ydl:
                ydl.download([self.url])
            self.objects.Finish.emit(True)
        except Exception as e:
            print(e)
            self.objects.Finish.emit(False)
    def progress_hook(self, d):
        if d['status'] == 'downloading':
            if 'downloaded_bytes' in d and 'total_bytes' in d:
                percent=int(d['downloaded_bytes'] / d['total_bytes'] * 100)
                self.objects.progress.emit(percent)
class LowQualityVideoDownloadDialog(qt.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تنزيل كفيديو بأقل جودة")
        self.thread_pool=qt2.QThreadPool(self)
        self.حفظ=qt.QPushButton("تحديد مكان الحفظ أولاً (O)")
        self.حفظ.setShortcut("o")
        self.حفظ.setDefault(True)
        self.حفظ.clicked.connect(self.openFile)
        self.إظهار1=qt.QLabel("مسار الحفظ")
        self.التعديل=qt.QLineEdit()
        self.التعديل.setReadOnly(True)
        self.التعديل.setAccessibleName("مسار الحفظ")
        self.إظهار3=qt.QLabel("إدخال الرابط هنا")
        self.الرابط=qt.QLineEdit()
        self.الرابط.setAccessibleName("إدخال الرابط هنا")
        self.التحميل=qt.QPushButton("بدء التحميل (D)")
        self.التحميل.setDefault(True)
        self.التحميل.setShortcut("d")
        self.التحميل.clicked.connect(self.download)
        self.progress_bar=qt.QProgressBar()
        self.progress_bar.setValue(0)
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.حفظ)
        layout.addWidget(self.إظهار1)
        layout.addWidget(self.التعديل)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.إظهار3)
        layout.addWidget(self.الرابط)
        layout.addWidget(self.التحميل)
    def openFile(self):
        directory=qt.QFileDialog.getExistingDirectory(self, "اختر مكان الحفظ")
        if directory:
            self.التعديل.setText(directory)
    def download(self):
        if not self.الرابط.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء إدخال رابط الفيديو")
            return
        if not self.التعديل.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء تحديد مكان الحفظ")
            return
        qt.QMessageBox.information(self, "تنبيه", "لقد بدأ التحميل الآن، الرجاء الانتظار حتى يتم التحميل")
        self.التحميل.setDisabled(True)
        thread=YoutubeThread(self.الرابط.text(), self.التعديل.text(), self.progress_bar)
        thread.objects.Finish.connect(self.onFinish)
        thread.objects.progress.connect(self.update_progress)
        self.thread_pool.start(thread)
    def update_progress(self, value):
        self.progress_bar.setValue(value)
    def onFinish(self, state):
        if state:
            qt.QMessageBox.information(self, "تم", "تم التحميل بنجاح والحفظ")
        else:
            qt.QMessageBox.critical(self, "تنبيه", "فشلت عملية التحميل، ربما تكون المشكلة من الرابط أو الإنترنت")
        self.التحميل.setDisabled(False)
        self.progress_bar.setValue(0)