from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from PyQt6.QtCore import QEvent,Qt,QLocale
from yt_dlp import YoutubeDL
class YoutubeObjects(qt2.QObject):
    progress=qt2.pyqtSignal(int, str, int, int)  # تحديث الإشارة لتشمل معلومات الفيديو
    finished=qt2.pyqtSignal(bool)
class YoutubeThread(qt2.QRunnable):
    def __init__(self, url, path):
        super().__init__()
        self.objects=YoutubeObjects()
        self.url=url
        self.path=path
    def run(self):
        try:
            ydl_opts={
                'format': 'bestaudio/best',
                'outtmpl': f'{self.path}/%(title)s.%(ext)s',
                'progress_hooks': [self.progress_hook],
                'quiet': True,
            }
            with YoutubeDL(ydl_opts) as ydl:
                info_dict=ydl.extract_info(self.url, download=False)  # جلب معلومات الفيديو
                self.video_title = info_dict.get('title', 'Unknown Title')  # الحصول على عنوان الفيديو
                ydl.download([self.url])
            self.objects.finished.emit(True)
        except Exception as e:
            print(e)
            self.objects.finished.emit(False)
    def progress_hook(self, d):
        if d['status'] == 'downloading':
            total_bytes=d.get('total_bytes', 0)
            downloaded_bytes=d.get('downloaded_bytes', 0)
            if total_bytes > 0:
                progress_percentage=int((downloaded_bytes / total_bytes) * 100)
                self.objects.progress.emit(progress_percentage, self.video_title, downloaded_bytes, total_bytes)  # إرسال المعلومات
class HighQualityAudioDownloadDialog(qt.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تنزيل كصوت بأعلى جودة")
        self.resize(400,400)
        self.thread_pool=qt2.QThreadPool(self)
        self.حفظ=qt.QPushButton("تحديد مكان الحفظ أولاً (O)")
        self.حفظ.setShortcut("o")
        self.حفظ.setDefault(True)
        self.حفظ.clicked.connect(self.openFile)
        self.إظهار1=qt.QLabel("مسار الحفظ")
        self.التعديل=qt.QLineEdit()
        self.التعديل.setReadOnly(True)
        self.التعديل.setAccessibleName("مسار الحفظ")
        self.إظهار3=qt.QLabel("إدخال الرابط هنا")
        self.الرابط=qt.QLineEdit()
        self.الرابط.setAccessibleName("إدخال الرابط هنا")
        self.معلومة_هامة=qt.QLabel("تنبيه هام, عند بدء التحميل لا يمكنك إلغاء التحميل")
        self.التحميل=qt.QPushButton("بدء التحميل (D)")
        self.التحميل.setAccessibleDescription("تنبيه هام, عند بدء التحميل لا يمكنك إلغاء التحميل")
        self.التحميل.setDefault(True)
        self.التحميل.setShortcut("d")
        self.التحميل.clicked.connect(self.dl)
        self.progress_bar=qt.QProgressBar()
        self.progress_bar.setValue(0)                
        self.المعلومات=qt.QLabel("تفاصيل التحميل")
        self.info_text=qt.QTextEdit()
        self.info_text.setReadOnly(True)        
        self.info_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.info_text.setLineWrapMode(qt.QTextEdit.LineWrapMode.NoWrap)
        self.info_text.setAccessibleName("تفاصيل التحميل")
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.حفظ)
        layout.addWidget(self.إظهار1)
        layout.addWidget(self.التعديل)
        layout.addWidget(self.المعلومات)
        layout.addWidget(self.info_text)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.إظهار3)
        layout.addWidget(self.الرابط)
        layout.addWidget(self.معلومة_هامة)
        layout.addWidget(self.التحميل)        
    def openFile(self):
        directory=qt.QFileDialog.getExistingDirectory(self, "اختر مكان الحفظ")
        if directory:
            self.التعديل.setText(directory)
    def dl(self):
        if not self.الرابط.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء إدخال رابط الفيديو")
            return
        if not self.التعديل.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء تحديد مكان الحفظ")
            return
        qt.QMessageBox.information(self, "تنبيه", "لقد بدأ التحميل الآن، الرجاء الانتظار حتى يتم التحميل")
        self.التحميل.setDisabled(True)
        thread=YoutubeThread(self.الرابط.text(), self.التعديل.text())
        thread.objects.progress.connect(self.update_progress)
        thread.objects.finished.connect(self.onFinish)
        self.thread_pool.start(thread)
    def update_progress(self, value, video_title, downloaded_bytes, total_bytes):
        self.progress_bar.setValue(value)        
        cursor_position=self.info_text.textCursor().position()  # حفظ موضع المؤشر الحالي
        self.info_text.clear()
        info_message=f"عنوان الفيديو: {video_title}\n"
        info_message += f"تم تحميل: {downloaded_bytes / (1024 * 1024):.2f} ميجاباي تمن {total_bytes / (1024 * 1024):.2f} ميجابايت"
        self.info_text.append(info_message)        
        cursor=self.info_text.textCursor()
        cursor.setPosition(cursor_position)
        self.info_text.setTextCursor(cursor)
    def onFinish(self, state):
        if state:
            qt.QMessageBox.information(self, "تم", "تم التحميل بنجاح والحفظ")
        else:
            qt.QMessageBox.critical(self, "تنبيه", "فشلت عملية التحميل، ربما تكون المشكلة من الرابط أو الإنترنت")
        self.التحميل.setDisabled(False)
        self.progress_bar.setValue(0)
        self.info_text.clear()