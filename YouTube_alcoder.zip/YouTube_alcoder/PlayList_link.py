from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
import Playlist_audio_high_quality, Playlist_audio_low_quality, Playlist_video_high_quality, Playlist_video_low_quality
import Playlist_videos
class PlayList_link(qt.QDialog):
    def __init__(self, link):
        super().__init__()
        self.link=link
        self.resize(400, 200)
        self.setWindowTitle("تم اكتشاف رابط قائمة تشغيل")        
        self.فتح=qt.QPushButton("عرض فيديوهات قائمة التشغيل")
        self.فتح.setDefault(True)
        self.فتح.clicked.connect(self.show_playlist_videos)
        self.فتح.setShortcut("ctrl+o")
        self.تنزيل=qt.QPushButton("تنزيل قائمة التشغيل")
        self.تنزيل.setDefault(True)
        self.تنزيل.clicked.connect(self.download_playlist)
        qt1.QShortcut("ctrl+alt+a",self).activated.connect(self.download_video_high_quality)
        qt1.QShortcut("ctrl+alt+s",self).activated.connect(self.download_video_low_quality)
        qt1.QShortcut("ctrl+alt+d",self).activated.connect(self.download_audio_high_quality)
        qt1.QShortcut("ctrl+alt+f",self).activated.connect(self.download_audio_low_quality)
        l=qt.QVBoxLayout()
        l.addWidget(self.فتح)
        l.addWidget(self.تنزيل)
        self.setLayout(l)        
    def download_playlist(self):
        قائمة=qt.QMenu(self)
        تنزيل_فيديو_أعلى_جودة=قائمة.addAction("تنزيل كفيديو بأعلى جودة")
        تنزيل_فيديو_أقل_جودة = قائمة.addAction("تنزيل كفيديو بأقل جودة")
        تنزيل_فيديو_أعلى_جودة.triggered.connect(self.download_video_high_quality)
        تنزيل_فيديو_أقل_جودة.triggered.connect(self.download_video_low_quality)
        تنزيل_صوت_أعلى_جودة=قائمة.addAction("تنزيل كصوت بأعلى جودة")
        تنزيل_صوت_أقل_جودة = قائمة.addAction("تنزيل كصوت بأقل جودة")
        تنزيل_صوت_أعلى_جودة.triggered.connect(self.download_audio_high_quality)
        تنزيل_صوت_أقل_جودة.triggered.connect(self.download_audio_low_quality)
        قائمة.exec(qt1.QCursor.pos())    
    def show_playlist_videos(self):        
        self.playlist_videos_window = Playlist_videos.PlaylistVideosWindow(self.link)
        self.close()
        self.playlist_videos_window.exec()
    def download_video_high_quality(self):
        self.video_high_quality_download=Playlist_video_high_quality.dialog(self)
        self.video_high_quality_download.الرابط.setText(self.link)
        self.close()
        self.video_high_quality_download.exec()
    def download_video_low_quality(self):
        self.video_low_quality_download=Playlist_video_low_quality.dialog(self)
        self.video_low_quality_download.الرابط.setText(self.link)
        self.close()
        self.video_low_quality_download.exec()
    def download_audio_high_quality(self):
        self.audio_high_quality_download=Playlist_audio_high_quality.dialog(self)
        self.audio_high_quality_download.الرابط(self.link)
        self.close()
        self.audio_high_quality_download.exec()
    def download_audio_low_quality(self):
        self.audio_low_quality_download=Playlist_audio_low_quality.dialog(self)
        self.audio_low_quality_download.الرابط.setText(self.link)
        self.close()
        self.audio_low_quality_download.exec()