from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from PyQt6.QtCore import QEvent,Qt,QLocale
from pytube import Playlist
from yt_dlp import YoutubeDL
import os
class YoutubeObjects(qt2.QObject):
    Finish=qt2.pyqtSignal(bool)
    Progress=qt2.pyqtSignal(int)
    UpdateInfo=qt2.pyqtSignal(str)
class YoutubeThread(qt2.QRunnable):
    def __init__(self, url, path, progress_bar, info_text):
        super().__init__()
        self.objects=YoutubeObjects()
        self.url=url
        self.path=path
        self.progress_bar=progress_bar
        self.info_text=info_text
    def run(self):
        try:
            playlist=Playlist(self.url)
            video_urls=playlist.video_urls
            if not video_urls:
                raise Exception("هذه ليست قائمة تشغيل")            
            total_videos=len(video_urls)
            current_video=0        
            for video_url in video_urls:
                try:
                    current_video += 1
                    info_message=f"جاري تحميل الفيديو {current_video} من {total_videos}..."
                    self.objects.UpdateInfo.emit(info_message)
                    self.download_audio(video_url, current_video, total_videos)                                    
                    info_message=f"تم تحميل الفيديو {current_video} من {total_videos}."
                    self.objects.UpdateInfo.emit(info_message)                    
                except Exception as e:
                    print(f"فشل تحميل {video_url}: {e}")            
            self.objects.Finish.emit(True)
        except Exception as e:
            print(e)
            self.objects.Finish.emit(False)
    def download_audio(self, video_url, current_video, total_videos):
        def progress_hook(d):
            if d['status'] == 'downloading':
                if 'downloaded_bytes' in d and 'total_bytes' in d:
                    downloaded_bytes=d['downloaded_bytes']
                    total_bytes=d['total_bytes']
                    percent=int(downloaded_bytes / total_bytes * 100)
                    video_title=d.get('info_dict', {}).get('title', 'فيديو غير معروف')                                    
                    info_message=(
                        f"جاري تحميل الفيديو {current_video} من {total_videos}...\n"
                        f"عنوان الفيديو: {video_title}\n"
                        f"تم تحميل: {downloaded_bytes / (1024 * 1024):.2f} ميجابايت من {total_bytes / (1024 * 1024):.2f} ميجابايت"
                    )
                    self.objects.UpdateInfo.emit(info_message)
                    self.objects.Progress.emit(percent)
        ydl_opts={
            'format': 'bestaudio/best',
            'outtmpl': os.path.join(self.path, '%(title)s.%(ext)s'),
            'progress_hooks': [progress_hook],
            'quiet': True,
        }
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
class dialog(qt.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تنزيل قائمة التشغيل كصوت بأعلى جودة")
        self.resize(500,400)        
        qt1.QShortcut("escape", self).activated.connect(lambda: qt.QMessageBox.critical(self, "تنبيه", "للخروج وإلغاء التحميل استخدم اختصار alt + F4"))
        self.حفظ=qt.QPushButton("تحديد مكان الحفظ أولاً (O)")
        self.حفظ.setShortcut("o")
        self.حفظ.setDefault(True)
        self.حفظ.clicked.connect(self.openFile)
        self.إظهار1=qt.QLabel("مسار الحفظ")
        self.التعديل=qt.QLineEdit()
        self.التعديل.setReadOnly(True)
        self.التعديل.setAccessibleName("مسار الحفظ")
        self.إظهار3=qt.QLabel("إدخال الرابط هنا")
        self.الرابط=qt.QLineEdit()
        self.الرابط.setAccessibleName("إدخال الرابط هنا")        
        self.المعلومات=qt.QLabel("تفاصيل التحميل")
        self.info_text=qt.QTextEdit()
        self.info_text.setReadOnly(True)        
        self.info_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.info_text.setLineWrapMode(qt.QTextEdit.LineWrapMode.NoWrap)
        self.info_text.setAccessibleName("تفاصيل التحميل")
        self.التحميل=qt.QPushButton("بدء التحميل (D)")
        self.التحميل.setDefault(True)
        self.التحميل.setShortcut("d")
        self.التحميل.clicked.connect(self.download)
        self.progress_bar=qt.QProgressBar()
        self.progress_bar.setValue(0)        
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.حفظ)
        layout.addWidget(self.إظهار1)
        layout.addWidget(self.التعديل)
        layout.addWidget(self.المعلومات)
        layout.addWidget(self.info_text)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.إظهار3)
        layout.addWidget(self.الرابط)
        layout.addWidget(self.التحميل)
    def openFile(self):
        directory=qt.QFileDialog.getExistingDirectory(self, "اختر مكان الحفظ")
        if directory:
            self.التعديل.setText(directory)
    def download(self):
        if not self.الرابط.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء إدخال رابط القائمة")
            return
        if not self.التعديل.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء تحديد مكان الحفظ")
            return        
        qt.QMessageBox.information(self, "تنبيه", "لقد بدأ التحميل الآن، الرجاء الانتظار حتى يتم التحميل")
        self.التحميل.setDisabled(True)        
        thread=YoutubeThread(self.الرابط.text(), self.التعديل.text(), self.progress_bar, self.info_text)
        thread.objects.Finish.connect(self.onFinish)
        thread.objects.Progress.connect(self.update_progress)
        thread.objects.UpdateInfo.connect(self.update_info_text)
        qt2.QThreadPool(self).start(thread)
    def update_progress(self, value):
        self.progress_bar.setValue(value)
    def update_info_text(self, message):    
        cursor_position=self.info_text.textCursor().position()        
        self.info_text.clear()
        self.info_text.append(message)    
        cursor=self.info_text.textCursor()
        cursor.setPosition(cursor_position)
        self.info_text.setTextCursor(cursor)
    def onFinish(self, state):
        if state:
            qt.QMessageBox.information(self, "تم", "تم التحميل بنجاح والحفظ")
        else:
            qt.QMessageBox.critical(self, "تنبيه", "فشلت عملية التحميل، ربما تكون المشكلة من الرابط أو الإنترنت أو أنك نسيت تحديد مكان الحفظ")    
        self.التحميل.setDisabled(False)
        self.progress_bar.setValue(0)