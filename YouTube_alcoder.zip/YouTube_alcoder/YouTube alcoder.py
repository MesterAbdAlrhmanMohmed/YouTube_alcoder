from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from Playlist_videos import PlaylistVideosWindow
from description_window import DescriptionWindow
from comments_window import CommentsWindow
from subtitle_window import SubtitleWindow
from low_quality_video import LowQualityVideoWindow
from high_quality_video import HighQualityVideoWindow
from low_quality_audio import LowQualityAudioWindow
from high_quality_audio import HighQualityAudioWindow
from video_link import VideoLink
from PlayList_link import PlayList_link
import Playlist_audio_high_quality,Playlist_audio_low_quality,Playlist_video_high_quality,Playlist_video_low_quality,re
import Video_high_quality,Video_low_quality,Audio_high_quality,Audio_low_quality
import about,pyperclip,dic,winsound,Playlist,clip
import youtubesearchpython as ytsearch
import speech_recognition as sr
class WorkerThread(qt2.QThread):    
    result_signal=qt2.pyqtSignal(object)
    error_signal=qt2.pyqtSignal(str)
    def __init__(self, func, *args,**kwargs):
        super().__init__()
        self.func=func
        self.args=args
        self.kwargs=kwargs
    def run(self):
        try:
            result=self.func(*self.args, **self.kwargs)
            self.result_signal.emit(result)
        except Exception as e:
            self.error_signal.emit(str(e))            
class tab1(qt.QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()    
    def init_ui(self):        
        self.next_page_token=None
        self.عرض_فئة=qt.QLabel("تحديد فئة البحث")
        self.الفئة=qt.QComboBox()        
        self.الفئة.setAccessibleName("تحديد فئة البحث")
        self.الفئة.addItem("الفيديوهات")
        self.الفئة.addItem("قوائم التشغيل")        
        self.عرض_اللغات=qt.QLabel("قم باختيار لغة الإدخال الصوتي")
        self.اللغة=qt.QComboBox()
        self.اللغة.setAccessibleName("قم باختيار لغة الإدخال الصوتي")
        self.اللغة.addItems(dic.languages.keys())
        self.الصوتي=qt.QPushButton("بدء الإدخال الصوتي")
        self.الصوتي.setDefault(True)
        self.الصوتي.clicked.connect(self.record_and_recognize)
        self.عرض_البحث=qt.QLabel("أكتب محتوى البحث")
        self.البحث=qt.QLineEdit()
        self.البحث.setAccessibleName("أكتب محتوى البحث")
        self.بدء=qt.QPushButton("بدء البحث")
        self.بدء.setDefault(True)                        
        self.بدء.clicked.connect(self.r2)
        self.النتيجة=qt.QListWidget()
        self.النتيجة.setAccessibleName("نتائج البحث")                
        self.النتيجة.verticalScrollBar().valueChanged.connect(self.load_more_results)
        self.النتيجة.setContextMenuPolicy(qt2.Qt.ContextMenuPolicy.CustomContextMenu)        
        self.النتيجة.customContextMenuRequested.connect(self.player)                
        self.النتيجة.clicked.connect(self.player)        
        qt1.QShortcut("ctrl+q",self).activated.connect(lambda: self.البحث.setFocus())                
        qt1.QShortcut("ctrl+a",self).activated.connect(lambda: self.open_window('high_quality_video'))
        qt1.QShortcut("ctrl+s",self).activated.connect(lambda: self.open_window('low_quality_video'))
        qt1.QShortcut("ctrl+d",self).activated.connect(lambda: self.open_window('high_quality_audio'))
        qt1.QShortcut("ctrl+f",self).activated.connect(lambda: self.open_window('low_quality_audio'))
        qt1.QShortcut("ctrl+shift+a",self).activated.connect(lambda: self.download_video_high_quality())
        qt1.QShortcut("ctrl+shift+s",self).activated.connect(lambda: self.download_video_low_quality())
        qt1.QShortcut("ctrl+shift+d",self).activated.connect(lambda: self.download_audio_high_quality())
        qt1.QShortcut("ctrl+shift+f",self).activated.connect(lambda: self.download_audio_low_quality())
        qt1.QShortcut("ctrl+o",self).activated.connect(lambda: self.open_playlist_videos(self.get_selected_item_link()))
        qt1.QShortcut("ctrl+alt+a",self).activated.connect(lambda: self.download_playlist_video_high_quality())
        qt1.QShortcut("ctrl+alt+s",self).activated.connect(lambda: self.download_playlist_video_low_quality())
        qt1.QShortcut("ctrl+alt+d",self).activated.connect(lambda: self.download_playlist_audio_high_quality())
        qt1.QShortcut("ctrl+alt+f",self).activated.connect(lambda: self.download_playlist_audio_low_quality())
        layout=qt.QVBoxLayout()
        layout.addWidget(self.عرض_فئة)
        layout.addWidget(self.الفئة)
        layout.addWidget(self.عرض_اللغات)
        layout.addWidget(self.اللغة)
        layout.addWidget(self.الصوتي)
        layout.addWidget(self.عرض_البحث)
        layout.addWidget(self.البحث)
        layout.addWidget(self.بدء)
        layout.addWidget(self.النتيجة)
        self.setLayout(layout)        
        self.check_clipboard()
    def check_clipboard(self):
        clipboard_content=pyperclip.paste()
        if self.is_youtube_video(clipboard_content):
            self.open_video_window(clipboard_content)
        elif self.is_youtube_playlist(clipboard_content):
            self.open_playlist_window(clipboard_content)    
    def is_youtube_video(self,url):
        video_pattern=re.compile(
            r'(https?://)?(www\.)?youtube\.com/watch\?v=[\w-]+'
            r'|https?://youtu\.be/[\w-]+', re.IGNORECASE)
        return bool(video_pattern.match(url))
    def is_youtube_playlist(self,url):
        playlist_pattern=re.compile(
            r'(https?://)?(www\.)?youtube\.com/playlist\?list=[\w-]+', re.IGNORECASE)
        return bool(playlist_pattern.match(url))
    def open_video_window(self,link):
        self.video_window=VideoLink(link)
        self.video_window.exec()
    def open_playlist_window(self,link):
        self.playlist_window=PlayList_link(link)
        self.playlist_window.exec()
    def player(self, position):
        القائمة = qt.QMenu(self)
        فئة_البحث = self.الفئة.currentText()
        if فئة_البحث == "الفيديوهات":
            قائمة_تشغيل_فيديو = القائمة.addMenu("تشغيل كفيديو")
            فيديو_بجودة_عالية = قائمة_تشغيل_فيديو.addAction("أعلى جودة")
            فيديو_بجودة_منخفضة = قائمة_تشغيل_فيديو.addAction("أقل جودة")
            قائمة_تشغيل_صوت = القائمة.addMenu("تشغيل كصوت")
            صوت_بجودة_عالية = قائمة_تشغيل_صوت.addAction("أعلى جودة")
            صوت_بجودة_منخفضة = قائمة_تشغيل_صوت.addAction("أقل جودة")
            قائمة_تنزيل = القائمة.addMenu("تنزيل المقطع")
            تنزيل_فيديو_بجودة_عالية = قائمة_تنزيل.addAction("تنزيل كفيديو بأعلى جودة")
            تنزيل_فيديو_بجودة_منخفضة = قائمة_تنزيل.addAction("تنزيل كفيديو بأقل جودة")
            تنزيل_صوت_بجودة_عالية = قائمة_تنزيل.addAction("تنزيل كصوت بأعلى جودة")
            تنزيل_صوت_بجودة_منخفضة = قائمة_تنزيل.addAction("تنزيل كصوت بأقل جودة")
            قائمة_خيارات_الفيديو = القائمة.addMenu("المزيد من الخيارات")
            رابط = قائمة_خيارات_الفيديو.addAction("نسخ الرابط")
            الوصف = قائمة_خيارات_الفيديو.addAction("عرض الوصف")
            التعليقات = قائمة_خيارات_الفيديو.addAction("عرض التعليقات")
            الترجمة=قائمة_خيارات_الفيديو.addAction("عرض ترجمة الفيديو subtitle")
            فيديو_بجودة_عالية.triggered.connect(lambda: self.open_window('high_quality_video'))
            فيديو_بجودة_منخفضة.triggered.connect(lambda: self.open_window('low_quality_video'))
            صوت_بجودة_عالية.triggered.connect(lambda: self.open_window('high_quality_audio'))
            صوت_بجودة_منخفضة.triggered.connect(lambda: self.open_window('low_quality_audio'))
            تنزيل_فيديو_بجودة_عالية.triggered.connect(lambda: self.download_video_high_quality())
            تنزيل_فيديو_بجودة_منخفضة.triggered.connect(lambda: self.download_video_low_quality())
            تنزيل_صوت_بجودة_عالية.triggered.connect(lambda: self.download_audio_high_quality())
            تنزيل_صوت_بجودة_منخفضة.triggered.connect(lambda: self.download_audio_low_quality())
            رابط.triggered.connect(self.copy_link)
            الوصف.triggered.connect(self.show_video_description)
            التعليقات.triggered.connect(self.show_comments_window)
            الترجمة.triggered.connect(self.show_subtitles)
        elif فئة_البحث == "قوائم التشغيل":
            رابط_القائمة = القائمة.addAction("نسخ رابط قائمة التشغيل")
            فتح_القائمة = القائمة.addAction("عرض فيديوهات قائمة التشغيل")
            تنزيل_فيديو_قائمة = القائمة.addAction("تنزيل قائمة التشغيل كفيديو بأعلى جودة")
            تنزيل_فيديو_قائمة_ضعيف = القائمة.addAction("تنزيل قائمة التشغيل كفيديو بأقل جودة")
            تنزيل_صوت_قائمة = القائمة.addAction("تنزيل قائمة التشغيل كصوت بأعلى جودة")
            تنزيل_صوت_قائمة_ضعيف = القائمة.addAction("تنزيل قائمة التشغيل كصوت بأقل جودة")
            رابط_القائمة.triggered.connect(self.copy_link)
            فتح_القائمة.triggered.connect(lambda: self.open_playlist_videos(self.get_selected_item_link()))
            تنزيل_فيديو_قائمة.triggered.connect(lambda: self.download_playlist_video_high_quality())
            تنزيل_فيديو_قائمة_ضعيف.triggered.connect(lambda: self.download_playlist_video_low_quality())
            تنزيل_صوت_قائمة.triggered.connect(lambda: self.download_playlist_audio_high_quality())
            تنزيل_صوت_قائمة_ضعيف.triggered.connect(lambda: self.download_playlist_audio_low_quality())
        القائمة.exec(self.النتيجة.viewport().mapToGlobal(position))
    def handle_error(self, error):        
        qt.QMessageBox.critical(self, "تنبيه", f"حدث خطأ: {error}")        
    def results(self):        
        self.next_page_token=None
        self.النتيجة.clear()        
        self.load_more_results()                                
    def show_subtitles(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.subtitle_dialog=SubtitleWindow(url)
        self.subtitle_dialog.show()
    def download_playlist_video_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Playlist_video_high_quality.dialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_playlist_video_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Playlist_video_low_quality.dialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_playlist_audio_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Playlist_audio_high_quality.dialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_playlist_audio_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Playlist_audio_low_quality.dialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_video_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Video_high_quality. HighQualityVideoDownloadDialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_video_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Video_low_quality. LowQualityVideoDownloadDialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_audio_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Audio_high_quality. HighQualityAudioDownloadDialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def download_audio_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.dlg=Audio_low_quality. LowQualityAudioDownloadDialog()
        self.dlg.الرابط.setText(url)
        self.dlg.show()
    def load_more_results(self):
        try:
            if self.النتيجة.verticalScrollBar().value() == self.النتيجة.verticalScrollBar().maximum():
                self.thread=WorkerThread(self._load_more_results)
                self.thread.result_signal.connect(self.handle_results)
                self.thread.error_signal.connect(self.handle_error)
                self.thread.start()
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def _load_more_results(self):
        try:
            search_query=self.البحث.text()
            search_category=self.الفئة.currentText()
            if not search_query:
                raise ValueError("يرجى إدخال كلمات للبحث")
            if search_category == "الفيديوهات":
                search=ytsearch.VideosSearch(search_query, limit=20)
            elif search_category == "قوائم التشغيل":
                search=ytsearch.PlaylistsSearch(search_query, limit=20)
            results=[]
            result_set=search.result()['result']
            results.extend(result_set)
            return results
        except Exception as e:            
            raise e        
    def handle_results(self, results):
        try:
            search_category=self.الفئة.currentText()
            for item in results:
                if search_category == "الفيديوهات":
                    title=item['title']
                    duration=item.get('duration', 'No duration available')
                    views=item.get('viewCount', {}).get('text', 'No views available')
                    channel_name=item['channel'].get('name', 'No channel name available')
                    link = item['link']
                    item_text=f"{title} - المدة {duration} - {channel_name} - {views}"
                elif search_category == "قوائم التشغيل":
                    title = item['title']
                    video_count=item.get('videoCount', 'No video count available')
                    channel_name=item['channel'].get('name', 'No channel name available')
                    link=item['link']
                    item_text=f"{title} - {video_count} - {channel_name}"
                item_obj=qt.QListWidgetItem(item_text)
                item_obj.setData(qt2.Qt.ItemDataRole.UserRole,link)
                self.النتيجة.addItem(item_obj)                                                            
                self.النتيجة.setFocus()                
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدث خطأ أثناء عرض النتائج: {e}")
    def r2(self):                
        try:
            self.results()
            qt2.QTimer.singleShot(100,self.results)                
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def record_and_recognize(self):
        try:
            self.الصوتي.setDisabled(True)
            self.thread=WorkerThread(self._record_and_recognize)
            self.thread.result_signal.connect(self.handle_recognition_result)
            self.thread.error_signal.connect(self.handle_error)
            self.thread.start()
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def _record_and_recognize(self):
        try:
            lang=dic.languages[self.اللغة.currentText()]
            التعرف=sr.Recognizer()
            with sr.Microphone() as source:
                winsound.PlaySound("data/1.wav", winsound.SND_FILENAME)
                الصوت=التعرف.listen(source)
                try:
                    winsound.PlaySound("data/2.wav", winsound.SND_FILENAME)
                    self.الصوتي.setDisabled(False)
                    النص=التعرف.recognize_google(الصوت, language=lang)                
                    return النص            
                except sr.UnknownValueError:
                    raise ValueError("لم أستطع فهم الصوت")
                except sr.RequestError as e:
                    raise ValueError("حدثت مشكلة أثناء جلب النص")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def handle_recognition_result(self, النص):
        try:
            self.البحث.setText(النص)
            self.البحث.setFocus()    
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def show_video_description(self):
        video_url=self.get_selected_item_link()
        if not video_url:
            return
        self.description_window=DescriptionWindow(video_url)
        self.description_window.show()
    def open_playlist_videos(self, playlist_url):
        try:
            self.playlist_videos_window=PlaylistVideosWindow(playlist_url)
            self.playlist_videos_window.show()
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def open_window(self, window_type):
        url=self.get_selected_item_link()
        if not url:
            return
        if window_type=='high_quality_video':
            self.video_window=HighQualityVideoWindow(url)
            self.video_window.show()
        elif window_type=='high_quality_audio':
            self.audio_window=HighQualityAudioWindow(url)
            self.audio_window.show()
        elif window_type=='low_quality_video':
            self.low_video_window=LowQualityVideoWindow(url)
            self.low_video_window.show()
        elif window_type=='low_quality_audio':
            self.low_audio_window=LowQualityAudioWindow(url)
            self.low_audio_window.show()
    def show_comments_window(self):
        video_url=self.get_selected_item_link()
        if not video_url:
            return
        self.comments_window=CommentsWindow(video_url)
        self.comments_window.show()
    def get_selected_item_link(self):
        try:
            selected_item=self.النتيجة.currentItem()
            url=selected_item.data(qt2.Qt.ItemDataRole.UserRole)
            return url
        except Exception:
            qt.QMessageBox.critical(self, "تنبيه", "لم يتم تحديد عنصر")
            return None
    def copy_link(self):
        try:
            selected_item=self.النتيجة.currentItem()
            url=selected_item.data(qt2.Qt.ItemDataRole.UserRole)
            pyperclip.copy(url)
            winsound.Beep(1000,100)
        except Exception:
            qt.QMessageBox.critical(self, "تنبيه", "حدث خطأ أثناء النسخ")
class tab2(qt.QWidget):
    def __init__(self):
        super().__init__()        
        self.إظهار1=qt.QLabel("إدخال رابط قائمة تشغيل")
        self.قائمة=qt.QLineEdit()
        self.قائمة.setAccessibleName("إدخال رابط قائمة تشغيل")
        self.فتح_قائمة=qt.QPushButton("فتح قائمة التشغيل")
        self.فتح_قائمة.setDefault(True)
        self.فتح_قائمة.clicked.connect(self.playlist)
        self.إظهار_الوصف=qt.QLabel("إدخال رابط فيديو أو قائمة تشغيل")
        self.فيديو_الوصف=qt.QLineEdit()
        self.فيديو_الوصف.setAccessibleName("إدخال رابط فيديو أو قائمة تشغيل")
        self.الوصف=qt.QPushButton("عرض الوصف")
        self.الوصف.setDefault(True)
        self.الوصف.clicked.connect(self.DX)
        self.إظهار_التعليقات=qt.QLabel("إدخال رابط فيديو")
        self.فيديو_التعليقات=qt.QLineEdit()
        self.فيديو_التعليقات.setAccessibleName("إدخال رابط فيديو")
        self.التعليقات=qt.QPushButton("عرض التعليقات")
        self.التعليقات.setDefault(True)
        self.التعليقات.clicked.connect(self.CO)
        self.إظهار2=qt.QLabel("إدخال رابط فيديو")
        self.فيديو=qt.QLineEdit()
        self.فيديو.setAccessibleName("إدخال رابط فيديو")
        self.تشغيل_فيديو_أعلى=qt.QPushButton("تشغيل فيديو بأعلى جودة")
        self.تشغيل_فيديو_أقل=qt.QPushButton("تشغيل فيديو بأقل جودة")
        self.تشغيل_صوت_أعلى=qt.QPushButton("تشغيل صوت بأعلى جودة")
        self.تشغيل_صوت_أقل=qt.QPushButton("تشغيل صوت بأقل جودة")
        self.تشغيل_صوت_أقل.setDefault(True)
        self.تشغيل_صوت_أعلى.setDefault(True)
        self.تشغيل_فيديو_أعلى.setDefault(True)
        self.تشغيل_فيديو_أقل.setDefault(True)
        self.تشغيل_صوت_أعلى.clicked.connect(self.HA)
        self.تشغيل_صوت_أقل.clicked.connect(self.LA)
        self.تشغيل_فيديو_أقل.clicked.connect(self.LV)
        self.تشغيل_فيديو_أعلى.clicked.connect(self.HV)        
        l=qt.QVBoxLayout()
        l.addWidget(self.إظهار1)
        l.addWidget(self.قائمة)
        l.addWidget(self.فتح_قائمة)
        l.addWidget(self.إظهار_الوصف)
        l.addWidget(self.فيديو_الوصف)
        l.addWidget(self.الوصف)
        l.addWidget(self.إظهار_التعليقات)
        l.addWidget(self.فيديو_التعليقات)
        l.addWidget(self.التعليقات)
        l.addWidget(self.إظهار2)
        l.addWidget(self.فيديو)
        l.addWidget(self.تشغيل_فيديو_أعلى)
        l.addWidget(self.تشغيل_صوت_أعلى)
        l.addWidget(self.تشغيل_فيديو_أقل)
        l.addWidget(self.تشغيل_صوت_أقل)        
        self.setLayout(l)    
    def playlist(self):
        try:
            playlist_url=self.قائمة.text()
            if playlist_url:
                PlaylistVideos=PlaylistVideosWindow(playlist_url)
                PlaylistVideos.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط قائمة التشغيل")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def DX(self):
        try:
            url=self.فيديو_الوصف.text()
            if url:
                Video=DescriptionWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط فيديو أو قائمة تشغيل")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def CO(self):
        try:
            url=self.فيديو_التعليقات.text()
            if url:
                Video=CommentsWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط الفيديو")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def HV(self):
        try:
            url=self.فيديو.text()
            if url:
                Video=HighQualityVideoWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط الفيديو")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def LV(self):
        try:
            url=self.فيديو.text()
            if url:
                Video=LowQualityVideoWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط الفيديو")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")        
    def HA(self):
        try:
            url=self.فيديو.text()
            if url:
                Video=HighQualityAudioWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط الفيديو")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
    def LA(self):
        try:
            url=self.فيديو.text()
            if url:
                Video=LowQualityAudioWindow(url)
                Video.show()
            else:
                qt.QMessageBox.critical(self,"تنبيه","الرجاء إدخال رابط الفيديو")
        except:
            qt.QMessageBox.critical(self,"تنبيه","حدث خطأ")
class tab3(qt.QWidget):
    def __init__(self):
        super().__init__()        
        self.الخيارات=qt.QListWidget()        
        self.الخيارات.clicked.connect(self.ch)
        qt1.QShortcut("return",self).activated.connect(self.ch)
        self.الخيارات.addItem("تنزيل مقطع")        
        self.الخيارات.addItem("تنزيل قائمة تشغيل")        
        l=qt.QVBoxLayout()
        l.addWidget(self.الخيارات)
        self.setLayout(l)    
    def ch(self):
        العناصر=self.الخيارات.currentRow()        
        if العناصر==0:
            clip.dialog(self).show()
        elif العناصر==1:
            Playlist.dialog(self).show()
class tab4(qt.QWidget):
    def __init__(self):
        super().__init__()                        
        self.الدليل=qt.QListWidget()        
        self.الدليل.addItem("زر المسافة: تشغيل/إيقاف مؤقت")
        self.الدليل.addItem("home,S  إيقاف")
        self.الدليل.addItem("التقديم السريع لمدة 5 ثواني: alt+ السهم الأيمن")
        self.الدليل.addItem("الترجيع السريع لمدة 5 ثواني: alt+ السهم الأيسر")
        self.الدليل.addItem("التقديم السريع لمدة 10 ثواني: alt+ السهم الأعلى")
        self.الدليل.addItem("الترجيع السريع لمدة 10 ثواني: alt+ السهم الأسفل")
        self.الدليل.addItem("التقديم السريع لمدة 30 ثانية: CTRL+السهم الأيمن")
        self.الدليل.addItem("الترجيع السريع لمدة 30 ثانية: CTRL+السهم الأيسر")
        self.الدليل.addItem("التقديم السريع لمدة دقيقة: CTRL+السهم الأعلا")
        self.الدليل.addItem("الترجيع السريع لمدة دقيقة: CTRL+السهم الأسفل")
        self.الدليل.addItem("اختصارات Ctrl + الرقم للانتقال مباشرة إلى نسبة محددة من المقطع، على سبيل المثال، Ctrl + 1 للانتقال إلى 10% من المقطع، Ctrl + 2 للانتقال إلى 20%، وهكذا")
        self.الدليل.addItem("رفع الصوت: shift+ السهم الأعلى")
        self.الدليل.addItem("خفض الصوت: shift+ السهم الأسفل")
        self.الدليل.addItem("CTRL+Q الانتقال سريعا لمربع البحث")
        self.الدليل.addItem("CTRL+A التشغيل كفيديو بأعلى جودة")
        self.الدليل.addItem("CTRL+S التشغيل كفيديو بأقلجودة")
        self.الدليل.addItem("CTRL+D التشغيل كصوت بأعلى جودة")
        self.الدليل.addItem("CTRL+F التشغيل كصوت بأقل جودة")
        self.الدليل.addItem("CTRL+SHIFT+A التنزيل كفيديو بأعلى جودة")
        self.الدليل.addItem("CTRL+SHIFT+S التنزيل كفيديو بأقل جودة")
        self.الدليل.addItem("CTRL+SHIFT+D التنزيل كصوت بأعلى جودة")
        self.الدليل.addItem("CTRL+SHIFT+F التنزيل كصوت بأقل جودة")
        self.الدليل.addItem("CTRL+O عرض فيديوهات قائمة التشغيل")
        self.الدليل.addItem("CTRL+ALT+A تنزيل قائمة التشغيل كفيديو بأعلى جودة")
        self.الدليل.addItem("CTRL+ALT+S تنزيل قائمة التشغيل كفيديو بأقل جودة")
        self.الدليل.addItem("CTRL+ALT+D تنزيل قائمة التشغيل كصوت بأعلى جودة")
        self.الدليل.addItem("CTRL+ALT+F تنزيل قائمة التشغيل كصوت بأقل جودة")
        self.الدليل.addItem("CTRL+C نسخ التعليق, ونسخ الجزء المحدد من الوصف ومن ترجمة الفيديو")
        self.الدليل.addItem("CTRL+A نسخ كل الوصف وترجمة الفيديو")
        self.الدليل.addItem("CTRL+S حفظ الوصف وترجمة الفيديو كملف نصي")
        self.الدليل.addItem("CTRL+= تكبير الخط في نافذة الوصف وترجمة الفيديو")
        self.الدليل.addItem("CTRL+- تصغير الخط في نافذة الوصف وترجمة الفيديو")
        self.الدليل.addItem("ملاحظة, يمنع تماما الضغط على زر بدء البحث أكثر من مرة بسرعة, لأن هذا قد يسبب تعطل البرنامج")
        l=qt.QVBoxLayout()
        l.addWidget(self.الدليل)        
        self.setLayout(l)                
class main(qt.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setGeometry(100,100,1000,600)
        self.setWindowTitle("YouTube alcoder")
        self.التاب = qt.QTabWidget()        
        self.التاب.setAccessibleName("الخيارات")
        self.التاب.addTab(tab1(), "البحث في YouTube")
        self.التاب.addTab(tab2(), "التشغيل السريع")
        self.التاب.addTab(tab3(), "التنزيل")
        self.التاب.addTab(tab4(), "دليل المستخدم")
        self.عن = qt.QPushButton("عن المطور")
        self.عن.setDefault(True)
        self.عن.clicked.connect(self.about)        
        l=qt.QVBoxLayout()
        l.addWidget(self.التاب)
        l.addWidget(self.عن)        
        w=qt.QWidget()
        w.setLayout(l)
        self.setCentralWidget(w)        
    def about(self):
        about.dialog(self).exec()
app=qt.QApplication([])
app.setStyle("fusion")
w=main()        
w.show()
app.exec()