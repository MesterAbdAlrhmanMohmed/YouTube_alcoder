from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2 
class about_channel(qt.QWidget):
    def __init__(self):
        super().__init__()
class videos(qt.QWidget):
    def __init__(self):
        super().__init__()        
class playlists(qt.QWidget):
    def __init__(self):
        super().__init__()        
class ChannelWindow(qt.QDialog):
    def __init__(self,channel_name,link,parent=None):
        super().__init__(parent)
        self.showFullScreen()
        self.channel_name=channel_name        
        self.link=link        
        self.setWindowTitle(self.channel_name)        
        self.tabs=qt.QTabWidget()
        self.tabs.addTab(about_channel(),"حول القناة")
        self.tabs.addTab(videos(),"الفيديوهات")
        self.tabs.addTab(playlists(),"قوائم التشغيل")
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.tabs)