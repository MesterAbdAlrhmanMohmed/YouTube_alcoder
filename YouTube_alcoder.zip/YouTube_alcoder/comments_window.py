from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from mtranslate import translate
import pyperclip, dic, winsound
from youtube_comment_downloader import YoutubeCommentDownloader
class TranslatorWorker(qt2.QObject):
    translation_finished=qt2.pyqtSignal(str)
    finished=qt2.pyqtSignal()
    def __init__(self, comment_text, language_code):
        super().__init__()
        self.comment_text=comment_text
        self.language_code=language_code
    def run(self):
        try:
            translated_comment=translate(self.comment_text, self.language_code, 'auto')
            self.translation_finished.emit(translated_comment)
        except Exception as e:
            print(f"Error during translation: {e}")
        finally:
            self.finished.emit()
class CommentsLoaderWorker(qt2.QObject):
    comment_loaded=qt2.pyqtSignal(str)
    finished=qt2.pyqtSignal()
    def __init__(self, video_url):
        super().__init__()
        self.video_url=video_url
        self._is_running=True
    def run(self):
        try:
            downloader=YoutubeCommentDownloader()
            for comment in downloader.get_comments_from_url(self.video_url):
                if not self._is_running:
                    break
                if 'reply' not in comment or not comment['reply']:  # Skip replies
                    self.comment_loaded.emit(comment['text'])
            self.finished.emit()
        except Exception as e:
            print(f"Error loading comments: {e}")
            self.finished.emit()
    def stop(self):
        self._is_running=False
class CommentsWindow(qt.QDialog):
    def __init__(self, video_url, parent=None):
        super().__init__(parent)
        self.setWindowTitle("التعليقات")
        self.showFullScreen()
        self.video_url=video_url
        self.setup_ui()
        self.load_comments_threaded()
    def setup_ui(self):
        qt1.QShortcut("escape", self).activated.connect(lambda: qt.QMessageBox.critical(self, "تنبيه", "للخروج استخدم اختصار alt + F4"))
        qt1.QShortcut("ctrl+c", self).activated.connect(self.copy_selected_line)
        self.ترجمة_التعليقات_إلى=qt.QLabel("قم بتحديد لغة الترجمة:")
        self.اللغات=qt.QComboBox()
        self.اللغات.setAccessibleName("قم بتحديد لغة الترجمة:")
        self.اللغات.addItems(dic.languages.keys())
        self.ترجمة_التعليقات=qt.QPushButton("ترجمة التعليق")
        self.ترجمة_التعليقات.setDefault(True)
        self.ترجمة_التعليقات.clicked.connect(self.translate_selected_comment)
        self.comments_list=qt.QListWidget()
        self.comments_list.setAccessibleName("التعليقات")
        self.comments_list.clicked.connect(self.translate_selected_comment)
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.ترجمة_التعليقات_إلى)
        layout.addWidget(self.اللغات)
        layout.addWidget(self.ترجمة_التعليقات)
        layout.addWidget(self.comments_list)
        self.setLayout(layout)
    def load_comments_threaded(self):
        self.comment_thread=qt2.QThread()
        self.comment_worker=CommentsLoaderWorker(self.video_url)
        self.comment_worker.moveToThread(self.comment_thread)
        self.comment_thread.started.connect(self.comment_worker.run)
        self.comment_worker.finished.connect(self.comment_thread.quit)
        self.comment_worker.finished.connect(self.comment_worker.deleteLater)
        self.comment_thread.finished.connect(self.comment_thread.deleteLater)
        self.comment_worker.comment_loaded.connect(self.add_comment_item)
        self.comment_thread.start()
    def add_comment_item(self, comment_text):
        comment_item=qt.QListWidgetItem(comment_text)
        self.comments_list.addItem(comment_item)
    def copy_selected_line(self):
        try:
            selected_items=self.comments_list.selectedItems()
            if selected_items:
                selected_line = selected_items[0].text()
                pyperclip.copy(selected_line)
                winsound.Beep(1000, 100)
        except:
            qt.QMessageBox.critical(self, "تنبيه", "حدثت مشكلة أثناء النسخ")
    def translate_selected_comment(self):
        try:
            selected_items=self.comments_list.selectedItems()
            if selected_items:
                selected_comment_item = selected_items[0]
                selected_comment_text = selected_comment_item.text()
                language_code=dic.languages[self.اللغات.currentText()]                
                self.translation_thread=qt2.QThread()
                self.translation_worker=TranslatorWorker(selected_comment_text, language_code)
                self.translation_worker.moveToThread(self.translation_thread)                
                self.translation_worker.translation_finished.connect(lambda text: self.update_comment_text(selected_comment_item, text))
                self.translation_worker.finished.connect(self.translation_thread.quit)
                self.translation_worker.finished.connect(self.translation_worker.deleteLater)
                self.translation_thread.finished.connect(self.translation_thread.deleteLater)                
                self.translation_thread.started.connect(self.translation_worker.run)
                self.translation_thread.start()
            else:
                qt.QMessageBox.critical(self, "تنبيه", "يرجى تحديد تعليق لترجمته")
        except Exception as e:
            print(e)
            qt.QMessageBox.critical(self, "تنبيه", "حدثت مشكلة أثناء الترجمة")
    def update_comment_text(self, comment_item, text):
        comment_item.setText(text)
        self.comments_list.setFocus()