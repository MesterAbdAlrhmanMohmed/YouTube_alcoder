from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from PyQt6.QtCore import Qt
from mtranslate import translate
import pyperclip, yt_dlp, dic, os, winsound
class DescriptionLoaderWorker(qt2.QObject):
    description_loaded=qt2.pyqtSignal(str)
    finished=qt2.pyqtSignal()
    def __init__(self, video_url):
        super().__init__()
        self.video_url=video_url
        self._is_running=True
    def run(self):
        try:
            ydl=yt_dlp.YoutubeDL({'extract_flat': True, 'force_generic_extractor': True})
            info=ydl.extract_info(self.video_url, download=False)
            description=info.get('description', '')
            for line in description.split('\n'):
                if not self._is_running:
                    break
                self.description_loaded.emit(line)
            self.finished.emit()
        except Exception as e:
            print(f"Error loading description: {e}")
            self.finished.emit()
    def stop(self):
        self._is_running=False
class TranslationThread(qt2 .QThread):
    line_translated=qt2.pyqtSignal(int, str)
    error_occurred=qt2.pyqtSignal(str)
    def __init__(self, lines, language_code):
        super().__init__()
        self.lines=lines
        self.language_code=language_code
    def run(self):
        try:
            for index, line in enumerate(self.lines):
                if line.strip():
                    translated_line=translate(line, self.language_code, 'auto')
                    self.line_translated.emit(index, translated_line)
                else:
                    self.line_translated.emit(index, "")
        except Exception as e:
            self.error_occurred.emit(f"حدث خطأ أثناء الترجمة: {e}")
class DescriptionWindow(qt.QDialog):
    def __init__(self, video_url, parent=None):
        super().__init__(parent)
        self.setWindowTitle("الوصف")
        self.showFullScreen()
        self.video_url=video_url
        self.font_size=20        
        self.load_description_threaded()    
        qt1.QShortcut("escape", self).activated.connect(lambda: qt.QMessageBox.critical(self, "تنبيه", "للخروج استخدم اختصار alt + F4"))
        qt1.QShortcut("ctrl+c", self).activated.connect(self.copy_selected_line)
        qt1.QShortcut("ctrl+a", self).activated.connect(self.copy_all)
        qt1.QShortcut("ctrl+=", self).activated.connect(self.increase_font_size)  # تكبير الخط
        qt1.QShortcut("ctrl+-", self).activated.connect(self.decrease_font_size)  # تصغير الخط        
        qt1.QShortcut("Ctrl+S", self).activated.connect(self.save_description_)        
        self.إظهار=qt.QLabel("قم بتحديد لغة للترجمة")        
        self.اللغات=qt.QComboBox()
        self.اللغات.setAccessibleName("قم بتحديد لغة للترجمة")
        self.اللغات.addItems(dic.languages.keys())            
        self.ترجمة_الوصف=qt.QPushButton("ترجمة الوصف")
        self.ترجمة_الوصف.setDefault(True)
        self.ترجمة_الوصف.clicked.connect(self.translate_description_threaded)        
        self.الوصف=qt.QTextEdit()
        self.الوصف.setReadOnly(True)
        self.الوصف.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.الوصف.setLineWrapMode(qt.QTextEdit.LineWrapMode.NoWrap)                    
        font=self.الوصف.font()
        font.setPointSize(self.font_size)
        self.الوصف.setFont(font)        
        layout=qt.QVBoxLayout(self)                
        layout.addWidget(self.إظهار)
        layout.addWidget(self.اللغات)
        layout.addWidget(self.ترجمة_الوصف)
        layout.addWidget(self.الوصف)
    def load_description_threaded(self):
        self.description_thread=qt2.QThread()
        self.description_worker = DescriptionLoaderWorker(self.video_url)
        self.description_worker.moveToThread(self.description_thread)        
        self.description_thread.started.connect(self.description_worker.run)
        self.description_worker.finished.connect(self.description_thread.quit)
        self.description_worker.finished.connect(self.description_worker.deleteLater)
        self.description_thread.finished.connect(self.description_thread.deleteLater)
        self.description_worker.description_loaded.connect(self.add_description_item)        
        self.description_thread.start()
    def add_description_item(self, description_line):
        self.الوصف.append(description_line)
        self.الوصف.moveCursor(qt1.QTextCursor.MoveOperation.Start)
    def translate_description_threaded(self):
        try:
            language_code=dic.languages[self.اللغات.currentText()]
            self.lines=self.الوصف.toPlainText().splitlines()
            if not self.lines:
                qt.QMessageBox.critical(self, "تنبيه", "لا يوجد نص للترجمة")
                return            
            self.translation_thread=TranslationThread(self.lines, language_code)
            self.translation_thread.line_translated.connect(self.update_line_translation)
            self.translation_thread.error_occurred.connect(self.show_error)
            self.translation_thread.start()
        except Exception as e:
            print(e)
            qt.QMessageBox.critical(self, "تنبيه", "حدث خطأ أثناء الترجمة")
    def update_line_translation(self, index, translated_line):
        cursor=self.الوصف.textCursor()
        cursor.movePosition(qt1.QTextCursor.MoveOperation.Start)
        for _ in range(index):
            cursor.movePosition(qt1.QTextCursor.MoveOperation.Down)
        cursor.select(qt1.QTextCursor.SelectionType.LineUnderCursor)
        cursor.removeSelectedText()
        cursor.insertText(translated_line)
    def update_translation(self, translated_text):
        self.الوصف.setText(translated_text)
        self.الوصف.setFocus()
    def show_error(self, error_message):
        qt.QMessageBox.critical(self, "خطأ", error_message)
    def copy_selected_line(self):
        try:
            selected_text=self.الوصف.textCursor().selectedText()
            if selected_text:
                pyperclip.copy(selected_text)
                winsound.Beep(1000, 100)
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء النسخ: {e}")
    def copy_all(self):
        try:
            all_text=self.الوصف.toPlainText()
            pyperclip.copy(all_text)
            winsound.Beep(1000, 100)
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء النسخ: {e}")
    def increase_font_size(self):
        self.font_size += 1
        self.update_font_size()
    def decrease_font_size(self):
        self.font_size -= 1
        self.update_font_size()
    def update_font_size(self):
        cursor=self.الوصف.textCursor()
        self.الوصف.selectAll()
        font=self.الوصف.font()
        font.setPointSize(self.font_size)
        self.الوصف.setFont(font)
        self.الوصف.setTextCursor(cursor)
    def save_description_(self):
        try:
            file_name, _ = qt.QFileDialog.getSaveFileName(self, "احفظ الوصف كملف نصي", "", "Text Files (*.txt);;All Files (*)")
            if file_name:
                with open(file_name, 'w', encoding='utf-8') as file:
                    file.write(self.الوصف.toPlainText())
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء الحفظ: {e}")