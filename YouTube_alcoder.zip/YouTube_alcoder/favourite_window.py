from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from Playlist_videos import PlaylistVideosWindow
from description_window import DescriptionWindow
from comments_window import CommentsWindow
from subtitle_window import SubtitleWindow
from low_quality_video import LowQualityVideoWindow
from high_quality_video import HighQualityVideoWindow
from low_quality_audio import LowQualityAudioWindow
from high_quality_audio import HighQualityAudioWindow
import Playlist_audio_high_quality,Playlist_audio_low_quality,Playlist_video_high_quality,Playlist_video_low_quality,re
import Video_high_quality,Video_low_quality,Audio_high_quality,Audio_low_quality
import os,json,pyperclip,winsound
class favourite_video(qt.QWidget):
    def __init__(self):
        super().__init__()        
        qt1.QShortcut("return",self).activated.connect(self.play_high_quality_video)
        qt1.QShortcut("ctrl+a",self).activated.connect(self.play_high_quality_video)
        qt1.QShortcut("ctrl+s",self).activated.connect(self.play_low_quality_video)
        qt1.QShortcut("ctrl+d",self).activated.connect(self.play_high_quality_audio)
        qt1.QShortcut("ctrl+f",self).activated.connect(self.play_low_quality_audio)
        qt1.QShortcut("ctrl+shift+a",self).activated.connect(self.download_video_high_quality)
        qt1.QShortcut("ctrl+shift+s",self).activated.connect(self.download_video_low_quality)
        qt1.QShortcut("ctrl+shift+d",self).activated.connect(self.download_audio_high_quality)
        qt1.QShortcut("ctrl+shift+f",self).activated.connect(self.download_audio_low_quality)
        self.قائمة_الفيديوهات=qt.QListWidget()
        self.قائمة_الفيديوهات.setContextMenuPolicy(qt2.Qt.ContextMenuPolicy.CustomContextMenu)        
        self.قائمة_الفيديوهات.customContextMenuRequested.connect(self.context_menu_videos)
        layout=qt.QVBoxLayout()
        layout.addWidget(self.قائمة_الفيديوهات)
        self.setLayout(layout)
        self.load_favourites()
    def context_menu_videos(self, position):
        menu=qt.QMenu(self)
        play_video_menu=menu.addMenu("تشغيل كفيديو")
        play_high_quality_video=play_video_menu.addAction("أعلى جودة")
        play_low_quality_video=play_video_menu.addAction("أقل جودة")    
        play_audio_menu=menu.addMenu("تشغيل كصوت")
        play_high_quality_audio=play_audio_menu.addAction("أعلى جودة")
        play_low_quality_audio=play_audio_menu.addAction("أقل جودة")    
        download_menu=menu.addMenu("تنزيل المقطع")
        download_video_high_quality=download_menu.addAction("تنزيل كفيديو بأعلى جودة")
        download_video_low_quality=download_menu.addAction("تنزيل كفيديو بأقل جودة")
        download_audio_high_quality=download_menu.addAction("تنزيل كصوت بأعلى جودة")
        download_audio_low_quality=download_menu.addAction("تنزيل كصوت بأقل جودة")
        more_options_menu=menu.addMenu("مزيد من الخيارات")
        copy_link=more_options_menu.addAction("نسخ رابط المقطع")
        show_description=more_options_menu.addAction("عرض الوصف")
        show_comments = more_options_menu.addAction("عرض التعليقات")
        show_subtitles = more_options_menu.addAction("عرض ترجمة الفيديو subtitle")
        remove_favourite = more_options_menu.addAction("الإزالة من المفضلة")            
        copy_link.triggered.connect(self.CopyLink)
        play_high_quality_video.triggered.connect(self.play_high_quality_video)
        play_low_quality_video.triggered.connect(self.play_low_quality_video)
        play_high_quality_audio.triggered.connect(self.play_high_quality_audio)
        play_low_quality_audio.triggered.connect(self.play_low_quality_audio)
        download_video_high_quality.triggered.connect(self.download_video_high_quality)
        download_video_low_quality.triggered.connect(self.download_video_low_quality)
        download_audio_high_quality.triggered.connect(self.download_audio_high_quality)
        download_audio_low_quality.triggered.connect(self.download_audio_low_quality)
        show_description.triggered.connect(self.show_description)
        show_comments.triggered.connect(self.show_comments)
        show_subtitles.triggered.connect(self.show_subtitles)
        remove_favourite.triggered.connect(self.remove_video_from_favourites)    
        menu.exec(self.قائمة_الفيديوهات.viewport().mapToGlobal(position))
    def load_favourites(self):
        try:
            file_path="database/favourite_videos.json"
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as file:
                    data=json.load(file)
                    for item in data:
                        list_item=qt.QListWidgetItem(item['title'])
                        list_item.setData(qt2.Qt.ItemDataRole.UserRole, item['url'])
                        self.قائمة_الفيديوهات.addItem(list_item)
        except Exception as e:
            qt.QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء تحميل المفضلة: {e}")        
    def remove_video_from_favourites(self):
        url=self.get_selected_item_link()
        if not url:
            return
        try:        
            file_path="database/favourite_videos.json"
            if os.path.exists(file_path):            
                with open(file_path, 'r', encoding='utf-8') as file:
                    data=json.load(file)                        
                data=[item for item in data if item['url'] != url]                        
                with open(file_path, 'w', encoding='utf-8') as file:
                    json.dump(data, file, ensure_ascii=False, indent=4)                        
                self.قائمة_الفيديوهات.takeItem(self.قائمة_الفيديوهات.currentRow())
                qt.QMessageBox.information(self, "تم", "تمت إزالة الفيديو من المفضلة")
        except Exception as e:
            qt.QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء إزالة الفيديو: {e}")
    def get_selected_item_link(self):
        selected_item=self.قائمة_الفيديوهات.currentItem()
        if selected_item:
            return selected_item.data(qt2.Qt.ItemDataRole.UserRole)
        return None
    def show_description(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.description_window=DescriptionWindow(url)
        self.description_window.exec()
    def show_comments(self):
        url = self.get_selected_item_link()
        if not url:
            return
        self.comments_window=CommentsWindow(url)
        self.comments_window.exec()
    def play_high_quality_video(self):
        url = self.get_selected_item_link()
        if not url:
            return
        self.high_quality_video_window=HighQualityVideoWindow(url)
        self.high_quality_video_window.exec()
    def play_low_quality_video(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.low_quality_video_window=LowQualityVideoWindow(url)
        self.low_quality_video_window.exec()
    def play_high_quality_audio(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.high_quality_audio_window=HighQualityAudioWindow(url)
        self.high_quality_audio_window.exec()
    def play_low_quality_audio(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.low_quality_audio_window=LowQualityAudioWindow(url)
        self.low_quality_audio_window.exec()
    def download_video_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.video_high_quality_download=Video_high_quality.HighQualityVideoDownloadDialog(self)
        self.video_high_quality_download.الرابط.setText(url)
        self.video_high_quality_download.exec()
    def download_video_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.video_low_quality_download=Video_low_quality.LowQualityVideoDownloadDialog(self)
        self.video_low_quality_download.الرابط.setText(url)
        self.video_low_quality_download.exec()
    def download_audio_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.audio_high_quality_download=Audio_high_quality.HighQualityAudioDownloadDialog(self)
        self.audio_high_quality_download.الرابط.setText(url)
        self.audio_high_quality_download.exec()
    def download_audio_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.audio_low_quality_download=Audio_low_quality.LowQualityAudioDownloadDialog(self)
        self.audio_low_quality_download.الرابط.setText(url)
        self.audio_low_quality_download.exec()
    def show_subtitles(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.subtitle_dialog=SubtitleWindow(url)
        self.subtitle_dialog.exec()
    def CopyLink(self):
        url=self.get_selected_item_link()
        if not url:
            return
        pyperclip.copy(url)
        winsound.Beep(1000,100)        
class favourite_playlist(qt.QWidget):
    def __init__(self):
        super().__init__()        
        qt1.QShortcut("return",self).activated.connect(self.show_playlist_videos)
        qt1.QShortcut("ctrl+alt+a",self).activated.connect(self.download_video_high_quality)
        qt1.QShortcut("ctrl+alt+s",self).activated.connect(self.download_video_low_quality)
        qt1.QShortcut("ctrl+alt+d",self).activated.connect(self.download_audio_high_quality)
        qt1.QShortcut("ctrl+alt+f",self).activated.connect(self.download_audio_low_quality)
        self.قائمة_التشغيل=qt.QListWidget()
        self.قائمة_التشغيل.setContextMenuPolicy(qt2.Qt.ContextMenuPolicy.CustomContextMenu)        
        self.قائمة_التشغيل.customContextMenuRequested.connect(self.context_menu_playlists)
        layout=qt.QVBoxLayout()
        layout.addWidget(self.قائمة_التشغيل)
        self.setLayout(layout)
        self.load_favourites()
    def context_menu_playlists(self, position):
        menu=qt.QMenu(self)
        copy_link=menu.addAction("نسخ رابط قائمة التشغيل")
        remove_from_favourite=menu.addAction("إزالة قائمة التشغيل من المفضلة")
        download_video_high_quality=menu.addAction("تنزيل كفيديو بأعلى جودة")
        download_video_low_quality=menu.addAction("تنزيل كفيديو بأقل جودة")
        download_audio_high_quality=menu.addAction("تنزيل كصوت بأعلى جودة")
        download_audio_low_quality=menu.addAction("تنزيل كصوت بأقل جودة")
        copy_link.triggered.connect(self.CopyLink)
        remove_from_favourite.triggered.connect(self.remove_playlist_from_favourites)
        download_video_high_quality.triggered.connect(self.download_video_high_quality)
        download_video_low_quality.triggered.connect(self.download_video_low_quality)
        download_audio_high_quality.triggered.connect(self.download_audio_high_quality)
        download_audio_low_quality.triggered.connect(self.download_audio_low_quality)    
        menu.exec(self.قائمة_التشغيل.viewport().mapToGlobal(position))
    def load_favourites(self):
        try:
            file_path="database/favourite_playlists.json"
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as file:
                    data=json.load(file)
                    for item in data:
                        list_item=qt.QListWidgetItem(item['title'])
                        list_item.setData(qt2.Qt.ItemDataRole.UserRole, item['url'])
                        self.قائمة_التشغيل.addItem(list_item)
        except Exception as e:
            qt.QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء تحميل المفضلة: {e}")    
    def remove_playlist_from_favourites(self):
        url=self.get_selected_item_link()
        if not url:
            return
        try:        
            file_path="database/favourite_playlists.json"
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as file:
                    data=json.load(file)                        
                data=[item for item in data if item['url'] != url]                        
                with open(file_path, 'w', encoding='utf-8') as file:
                    json.dump(data, file, ensure_ascii=False, indent=4)                        
                self.قائمة_التشغيل.takeItem(self.قائمة_التشغيل.currentRow())
                qt.QMessageBox.information(self, "تم", "تمت إزالة قائمة التشغيل من المفضلة")
        except Exception as e:
            qt.QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء إزالة قائمة التشغيل: {e}")
    def get_selected_item_link(self):
        selected_item=self.قائمة_التشغيل.currentItem()
        if selected_item:
            return selected_item.data(qt2.Qt.ItemDataRole.UserRole)
        return None
    def show_playlist_videos(self):        
        url=self.get_selected_item_link()
        if not url:
            return
        self.playlist_videos_window=PlaylistVideosWindow(url)
        self.playlist_videos_window.exec()
    def download_video_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.video_high_quality_download=Playlist_video_high_quality.dialog(self)
        self.video_high_quality_download.الرابط.setText(url)
        self.video_high_quality_download.exec()
    def download_video_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.video_low_quality_download=Playlist_video_low_quality.dialog(self)
        self.video_low_quality_download.الرابط.setText(url)
        self.video_low_quality_download.exec()
    def download_audio_high_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.audio_high_quality_download=Playlist_audio_high_quality.dialog(self)
        self.audio_high_quality_download.الرابط.setText(url)
        self.audio_high_quality_download.exec()
    def download_audio_low_quality(self):
        url=self.get_selected_item_link()
        if not url:
            return
        self.audio_low_quality_download=Playlist_audio_low_quality.dialog(self)
        self.audio_low_quality_download.الرابط.setText(url)
        self.audio_low_quality_download.exec()
    def CopyLink(self):
        url=self.get_selected_item_link()
        if not url:
            return
        pyperclip.copy(url)
        winsound.Beep(1000,100)        
class FavouriteWindow(qt.QDialog):
    def __init__(self):
        super().__init__()
        self.showFullScreen()        
        self.setWindowTitle("المفضلة")
        self.التاب=qt.QTabWidget()
        self.التاب.setAccessibleName("العناصر المفضلة")
        self.التاب.addTab(favourite_video(), "مقاطع الفيديو المفضلة")
        self.التاب.addTab(favourite_playlist(), "قوائم التشغيل المفضلة")
        layout=qt.QVBoxLayout()
        layout.addWidget(self.التاب)
        self.setLayout(layout)