from PyQt6 import QtWidgets as qt
from PyQt6.QtCore import Qt,QThread,pyqtSignal
import gdown,re,os,json
class DownloadThread(QThread):
    def __init__(self, url, output):
        super().__init__()
        self.url=url
        self.output=output
    def run(self):
        file_id=re.search(r'd/([a-zA-Z0-9_-]+)', self.url)
        if file_id:
            file_id=file_id.group(1)
            download_url=f'https://drive.google.com/uc?id={file_id}'
            gdown.download(download_url, self.output, quiet=True)
class updates(qt.QDialog):
    def __init__(self):
        super().__init__()
        self.resize(600, 400)
        self.setWindowTitle("تحديثات البرنامج")        
        self.حفظ=qt.QPushButton("تحديد مكان الحفظ أولاً (O)")
        self.حفظ.setShortcut("o")
        self.حفظ.setDefault(True)        
        self.حفظ.clicked.connect(self.openFile)        
        self.إظهار1=qt.QLabel("مسار الحفظ")
        self.التعديل=qt.QLineEdit()
        self.التعديل.setReadOnly(True)
        self.التعديل.setAccessibleName("مسار الحفظ")
        self.إظهار3=qt.QLabel("رابط تنزيل التحديث")
        self.الرابط=qt.QLineEdit()
        self.الرابط.setReadOnly(True)
        self.الرابط.setAccessibleName("رابط تنزيل التحديث")
        self.معلومة_هامة=qt.QLabel("تنبيه هام, عند بدء التحميل لا يمكنك إلغاء التحميل")
        self.التحميل=qt.QPushButton("بدء التحميل (D)")
        self.التحميل.setDefault(True)
        self.التحميل.setAccessibleDescription("تنبيه هام, عند بدء التحميل لا يمكنك إلغاء التحميل")
        self.التحميل.clicked.connect(self.download_update)
        self.info_label=qt.QLabel("تفاصيل التحميل")  # إضافة QLabel جديد
        self.info_text=qt.QTextEdit()
        self.info_text.setReadOnly(True)
        self.info_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.info_text.setLineWrapMode(qt.QTextEdit.LineWrapMode.NoWrap)        
        self.info_text.setAccessibleName("تفاصيل التحديث")
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.حفظ)
        layout.addWidget(self.إظهار1)
        layout.addWidget(self.التعديل)        
        layout.addWidget(self.info_label)  # إضافة QLabel لتفاصيل التحميل
        layout.addWidget(self.info_text)
        layout.addWidget(self.إظهار3)
        layout.addWidget(self.الرابط)        
        layout.addWidget(self.معلومة_هامة)
        layout.addWidget(self.التحميل)
        self.check_for_updates()
    def openFile(self):
        directory=qt.QFileDialog.getExistingDirectory(self, "اختر مكان حفظ التحديث")
        if directory:
            self.التعديل.setText(directory)
    def check_for_updates(self):        
        json_url="https://drive.google.com/file/d/1DN-ufdd0bFju5xE2H6lOIZs6zlFMhI3P/view?usp=drivesdk"  # رابط ملف JSON
        json_file="check_for_updates.json"
        self.download_from_drive(json_url, json_file)  # استدعاء دالة لتنزيل ملف JSON            
        self.process_json_file(json_file)
    def process_json_file(self, json_file):        
        with open(json_file,'r',encoding='utf-8') as file:
            data=json.load(file)
        current_version="20.0"
        new_version=data.get('new_version')
        update_details=data.get('details')
        update_url=data.get('download_link')
        if new_version and new_version != current_version:            
            update_message=f"يوجد تحديث جديد: الإصدار {new_version}\n\nتفاصيل التحديث:\n{update_details}"
            self.info_text.setPlainText(update_message)  # عرض معلومات التحديث
            self.الرابط.setText(update_url)
            self.update_url=update_url
            self.new_version=new_version
        else:
            self.info_text.setPlainText("لم يتم العثور على تحديثات.")
    def download_update(self):
        if not self.التعديل.text():
            qt.QMessageBox.critical(self, "تنبيه", "الرجاء تحديد مكان الحفظ")
            return
        if hasattr(self, 'update_url') and hasattr(self, 'new_version'):
            output_file=os.path.join(self.التعديل.text(), f"YouTube alcoder_{self.new_version}.exe")
            self.thread=DownloadThread(self.update_url, output_file)
            self.thread.start()
            self.info_text.clear()
            self.info_text.append("جارٍ تنزيل التحديث...")
            self.thread.finished.connect(self.download_finished)
        else:
            qt.QMessageBox.warning(self, "تنبيه", "لا يوجد رابط تحديث متاح.")
    def download_from_drive(self, url, output):        
        file_id=re.search(r'd/([a-zA-Z0-9_-]+)', url)
        if file_id:
            file_id=file_id.group(1)
            download_url=f'https://drive.google.com/uc?id={file_id}'
            gdown.download(download_url, output, quiet=True)  # لا تظهر أي رسائل
    def download_finished(self):
        self.info_text.clear()
        self.info_text.append("تم تنزيل التحديث")
        qt.QMessageBox.information(self,"تم","تم تنزيل ملف التحديث بنجاح")