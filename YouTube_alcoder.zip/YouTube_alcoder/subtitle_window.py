from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import yt_dlp, pyperclip, dic, winsound, requests
from mtranslate import translate
class SubtitleLoaderThread(QThread):
    subtitles_loaded=pyqtSignal(str)
    error_occurred=pyqtSignal(str)
    def __init__(self, video_url, language_code):
        super().__init__()
        self.video_url=video_url
        self.language_code=language_code
    def run(self):
        try:
            ydl=yt_dlp.YoutubeDL({'writesubtitles': True, 'subtitleslangs': [self.language_code]})
            info=ydl.extract_info(self.video_url, download=False)
            subtitles=info.get('subtitles', {}).get(self.language_code, [])
            if not subtitles:
                self.subtitles_loaded.emit('لا توجد ترجمات متاحة بهذه اللغة.')
                return
            subtitle_url=subtitles[0].get('url', '')
            if subtitle_url:
                response=requests.get(subtitle_url)
                response.raise_for_status()
                subtitle_data=response.json()
                subtitle_text=""
                for event in subtitle_data.get('events', []):
                    for segment in event.get('segs', []):
                        subtitle_text += segment.get('utf8', '') + '\n'
                self.subtitles_loaded.emit(subtitle_text.strip())
            else:
                self.subtitles_loaded.emit('لا توجد ترجمات متاحة.')
        except Exception as e:
            self.error_occurred.emit(f"حدثت مشكلة أثناء جلب الترجمة: {e}")
class TranslationThread(QThread):
    line_translated=pyqtSignal(int, str)
    error_occurred=pyqtSignal(str)
    def __init__(self, lines, language_code):
        super().__init__()
        self.lines=lines
        self.language_code=language_code
    def run(self):
        try:
            for index, line in enumerate(self.lines):
                if line.strip():
                    translated_line=translate(line, self.language_code, 'auto')
                    self.line_translated.emit(index, translated_line)
                else:
                    self.line_translated.emit(index, "")
        except Exception as e:
            self.error_occurred.emit(f"حدث خطأ أثناء الترجمة: {e}")
class SubtitleWindow(qt.QDialog):
    def __init__(self, video_url):
        super().__init__()
        self.setWindowTitle("عرض ترجمات الفيديوهات subtitles")
        self.showFullScreen()
        self.video_url=video_url
        self.font_size=20
        qt1.QShortcut("escape", self).activated.connect(lambda: qt.QMessageBox.critical(self, "تنبيه", "للخروج استخدم اختصار alt + F4"))
        qt1.QShortcut("ctrl+c", self).activated.connect(self.copy_selected_line)
        qt1.QShortcut("ctrl+a", self).activated.connect(self.copy_all)
        qt1.QShortcut("Ctrl+S", self).activated.connect(self.save_subtitles)
        qt1.QShortcut("ctrl+=", self).activated.connect(self.increase_font_size)
        qt1.QShortcut("ctrl+-", self).activated.connect(self.decrease_font_size)
        self.إظهار_اللغات=qt.QLabel("قم باختيار لغة الترجمة subtitle")
        self.اللغة=qt.QComboBox()
        self.اللغة.setAccessibleName("قم باختيار لغة الترجمة subtitle")
        self.اللغة.addItems(dic.languages.keys())
        self.بدء=qt.QPushButton("الحصول على الترجمة")
        self.بدء.clicked.connect(self.load_subtitles)
        self.ترجمة_الفيديو=qt.QTextEdit()
        self.ترجمة_الفيديو.setReadOnly(True)
        self.ترجمة_الفيديو.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByKeyboard | Qt.TextInteractionFlag.TextSelectableByMouse)
        self.ترجمة_الفيديو.setLineWrapMode(qt.QTextEdit.LineWrapMode.NoWrap)
        self.إظهار_ترجمة_الترجمة=qt.QLabel("قم بتحديد لغة ترجمة النص الحالي")
        self.لغات_الترجمة=qt.QComboBox()
        self.لغات_الترجمة.setAccessibleName("قم بتحديد لغة ترجمة النص الحالي")
        self.لغات_الترجمة.addItems(dic.languages.keys())
        self.بدء_الترجمة=qt.QPushButton("ترجمة النص")
        self.بدء_الترجمة.setDefault(True)
        self.بدء_الترجمة.clicked.connect(self.translate_subtitle)
        font=self.ترجمة_الفيديو.font()
        font.setPointSize(self.font_size)
        self.ترجمة_الفيديو.setFont(font)
        layout=qt.QVBoxLayout(self)
        layout.addWidget(self.إظهار_اللغات)
        layout.addWidget(self.اللغة)
        layout.addWidget(self.بدء)
        layout.addWidget(self.ترجمة_الفيديو)
        layout.addWidget(self.إظهار_ترجمة_الترجمة)
        layout.addWidget(self.لغات_الترجمة)
        layout.addWidget(self.بدء_الترجمة)
    def load_subtitles(self):
        language_code=dic.languages[self.اللغة.currentText()]
        self.thread=SubtitleLoaderThread(self.video_url, language_code)
        self.thread.subtitles_loaded.connect(self.update_subtitles)
        self.thread.error_occurred.connect(self.show_error)
        self.thread.start()
    def update_subtitles(self, subtitle_text):
        self.ترجمة_الفيديو.setPlainText(subtitle_text)
        self.ترجمة_الفيديو.moveCursor(qt1.QTextCursor.MoveOperation.Start)
        self.ترجمة_الفيديو.setFocus()
    def show_error(self, error_message):
        qt.QMessageBox.critical(self, "خطأ", error_message)
    def copy_selected_line(self):
        try:
            selected_text=self.ترجمة_الفيديو.textCursor().selectedText()
            if selected_text:
                pyperclip.copy(selected_text)
                winsound.Beep(1000, 100)
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء النسخ: {e}")
    def copy_all(self):
        try:
            all_text=self.ترجمة_الفيديو.toPlainText()
            pyperclip.copy(all_text)
            winsound.Beep(1000, 100)
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء النسخ: {e}")
    def increase_font_size(self):
        self.font_size += 1
        self.update_font_size()
    def decrease_font_size(self):
        self.font_size -= 1
        self.update_font_size()
    def update_font_size(self):
        cursor=self.ترجمة_الفيديو.textCursor()
        self.ترجمة_الفيديو.selectAll()
        font=self.ترجمة_الفيديو.font()
        font.setPointSize(self.font_size)
        self.ترجمة_الفيديو.setFont(font)
        self.ترجمة_الفيديو.setTextCursor(cursor)
    def save_subtitles(self):
        try:
            file_name, _ = qt.QFileDialog.getSaveFileName(self, "احفظ الترجمة كملف نصي", "", "Text Files (*.txt);;All Files (*)")
            if file_name:
                with open(file_name, 'w', encoding='utf-8') as file:
                    file.write(self.ترجمة_الفيديو.toPlainText())
        except Exception as e:
            qt.QMessageBox.critical(self, "تنبيه", f"حدثت مشكلة أثناء الحفظ: {e}")
    def translate_subtitle(self):
        try:
            language_code=dic.languages[self.لغات_الترجمة.currentText()]
            self.lines=self.ترجمة_الفيديو.toPlainText().splitlines()
            if not self.lines:
                qt.QMessageBox.critical(self, "تنبيه", "لا يوجد نص للترجمة")
                return            
            self.translation_thread=TranslationThread(self.lines, language_code)
            self.translation_thread.line_translated.connect(self.update_line_translation)
            self.translation_thread.error_occurred.connect(self.show_error)
            self.translation_thread.start()
        except Exception as e:
            print(e)
            qt.QMessageBox.critical(self, "تنبيه", "حدث خطأ أثناء الترجمة")
    def update_line_translation(self, index, translated_line):
        cursor=self.ترجمة_الفيديو.textCursor()
        cursor.movePosition(qt1.QTextCursor.MoveOperation.Start)
        for _ in range(index):
            cursor.movePosition(qt1.QTextCursor.MoveOperation.Down)
        cursor.select(qt1.QTextCursor.SelectionType.LineUnderCursor)
        cursor.removeSelectedText()
        cursor.insertText(translated_line)