from PyQt6 import QtWidgets as qt
from PyQt6 import QtGui as qt1
from PyQt6 import QtCore as qt2
from description_window import DescriptionWindow
from comments_window import CommentsWindow
from subtitle_window import SubtitleWindow
from low_quality_video import LowQualityVideoWindow
from high_quality_video import HighQualityVideoWindow
from low_quality_audio import LowQualityAudioWindow
from high_quality_audio import HighQualityAudioWindow
import Video_high_quality, Video_low_quality, Audio_high_quality, Audio_low_quality
class VideoLink(qt.QDialog):
    def __init__(self, link):
        super().__init__()
        self.link=link
        self.resize(400, 200)
        self.setWindowTitle("تم اكتشاف رابط فيديو YouTube")        
        self.التشغيل_فيديو=qt.QPushButton("التشغيل كفيديو")
        self.التشغيل_فيديو.setDefault(True)
        self.التشغيل_فيديو.clicked.connect(self.play_video)
        self.التشغيل_صوت=qt.QPushButton("التشغيل كصوت")
        self.التشغيل_صوت.setDefault(True)
        self.التشغيل_صوت.clicked.connect(self.play_audio)
        self.التنزيل=qt.QPushButton("تنزيل")
        self.التنزيل.setDefault(True)
        self.التنزيل.clicked.connect(self.download_video_or_audio)
        self.المزيد=qt.QPushButton("المزيد من الخيارات")
        self.المزيد.setDefault(True)
        self.المزيد.clicked.connect(self.show_more_options)
        qt1.QShortcut("ctrl+a",self).activated.connect(self.play_high_quality_video)
        qt1.QShortcut("ctrl+s",self).activated.connect(self.play_low_quality_video)
        qt1.QShortcut("ctrl+d",self).activated.connect(self.play_high_quality_audio)
        qt1.QShortcut("ctrl+f",self).activated.connect(self.play_low_quality_audio)
        qt1.QShortcut("ctrl+shift+a",self).activated.connect(self.download_video_high_quality)
        qt1.QShortcut("ctrl+shift+s",self).activated.connect(self.download_video_low_quality)
        qt1.QShortcut("ctrl+shift+d",self).activated.connect(self.download_audio_high_quality)
        qt1.QShortcut("ctrl+shift+f",self).activated.connect(self.download_audio_low_quality)
        layout=qt.QVBoxLayout()
        layout.addWidget(self.التشغيل_فيديو)
        layout.addWidget(self.التشغيل_صوت)
        layout.addWidget(self.التنزيل)
        layout.addWidget(self.المزيد)
        self.setLayout(layout)    
    def play_video(self):
        قائمة=qt.QMenu(self)
        التشغيل_أعلى = قائمة.addAction("أعلى جودة")
        التشغيل_أقل = قائمة.addAction("أقل جودة")
        التشغيل_أعلى.triggered.connect(self.play_high_quality_video)
        التشغيل_أقل.triggered.connect(self.play_low_quality_video)
        قائمة.exec(self.التشغيل_فيديو.mapToGlobal(self.التشغيل_فيديو.rect().bottomLeft()))    
    def play_audio(self):
        قائمة=qt.QMenu(self)
        التشغيل_أعلى = قائمة.addAction("أعلى جودة")
        التشغيل_أقل = قائمة.addAction("أقل جودة")
        التشغيل_أعلى.triggered.connect(self.play_high_quality_audio)
        التشغيل_أقل.triggered.connect(self.play_low_quality_audio)
        قائمة.exec(self.التشغيل_صوت.mapToGlobal(self.التشغيل_صوت.rect().bottomLeft()))    
    def download_video_or_audio(self):
        قائمة=qt.QMenu(self)
        التنزيل_فيديو_أعلى = قائمة.addAction("تنزيل فيديو بأعلى جودة")
        التنزيل_فيديو_أقل = قائمة.addAction("تنزيل فيديو بأقل جودة")
        التنزيل_صوت_أعلى = قائمة.addAction("تنزيل صوت بأعلى جودة")
        التنزيل_صوت_أقل = قائمة.addAction("تنزيل صوت بأقل جودة")
        التنزيل_فيديو_أعلى.triggered.connect(self.download_video_high_quality)
        التنزيل_فيديو_أقل.triggered.connect(self.download_video_low_quality)
        التنزيل_صوت_أعلى.triggered.connect(self.download_audio_high_quality)
        التنزيل_صوت_أقل.triggered.connect(self.download_audio_low_quality)
        قائمة.exec(self.التنزيل.mapToGlobal(self.التنزيل.rect().bottomLeft()))
    def show_more_options(self):
        قائمة=qt.QMenu(self)
        عرض_الوصف = قائمة.addAction("عرض الوصف")
        عرض_التعليقات = قائمة.addAction("عرض التعليقات")
        الترجمة=قائمة.addAction("عرض ترجمة الفيديو subtitle")
        عرض_الوصف.triggered.connect(self.show_description)
        عرض_التعليقات.triggered.connect(self.show_comments)
        الترجمة.triggered.connect(self.show_subtitles)
        قائمة.exec(self.المزيد.mapToGlobal(self.المزيد.rect().bottomLeft()))    
    def show_description(self):
        self.description_window=DescriptionWindow(self.link)
        self.close()
        self.description_window.exec()
    def show_comments(self):
        self.comments_window=CommentsWindow(self.link)
        self.close()
        self.comments_window.exec()
    def play_high_quality_video(self):
        self.high_quality_video_window=HighQualityVideoWindow(self.link)
        self.close()
        self.high_quality_video_window.exec()
    def play_low_quality_video(self):
        self.low_quality_video_window=LowQualityVideoWindow(self.link)
        self.close()
        self.low_quality_video_window.exec()
    def play_high_quality_audio(self):
        self.high_quality_audio_window=HighQualityAudioWindow(self.link)
        self.close()
        self.high_quality_audio_window.exec()
    def play_low_quality_audio(self):
        self.low_quality_audio_window=LowQualityAudioWindow(self.link)
        self.close()
        self.low_quality_audio_window.exec()
    def download_video_high_quality(self):
        self.video_high_quality_download=Video_high_quality.HighQualityVideoDownloadDialog(self)        
        self.video_high_quality_download.الرابط.setText(self.link)
        self.close()
        self.video_high_quality_download.exec()
    def download_video_low_quality(self):
        self.video_low_quality_download=Video_low_quality.LowQualityVideoDownloadDialog(self)        
        self.video_low_quality_download.الرابط.setText(self.link)
        self.close()
        self.video_low_quality_download.exec()
    def download_audio_high_quality(self):
        self.audio_high_quality_download=Audio_high_quality.HighQualityAudioDownloadDialog(self)        
        self.audio_high_quality_download.الرابط.setText(self.link)
        self.close()
        self.audio_high_quality_download.exec()
    def download_audio_low_quality(self):
        self.audio_low_quality_download=Audio_low_quality.LowQualityAudioDownloadDialog(self)
        self.audio_low_quality_download.الرابط.setText(self.link)                
        self.close()
        self.audio_low_quality_download.exec()
    def show_subtitles(self):                
        self.subtitle_dialog=SubtitleWindow(self.link)
        self.close()
        self.subtitle_dialog.exec()